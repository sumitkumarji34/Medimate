# 🩺 MediMate — Smart AI Medicine Management & Alarm Platform

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=flat&logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![Web Audio API](https://img.shields.io/badge/Web_Audio_API-Synthesizer-teal.svg)](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API)
[![Tesseract OCR](https://img.shields.io/badge/OCR-Tesseract.js_v5-orange.svg)](https://tesseract.projectnaptha.com/)
[![Status](https://img.shields.io/badge/Status-Production_Ready-emerald.svg)]()

> **Never Miss Your Medicine Again.**  
> MediMate is an intelligent, privacy-first healthcare platform that automates prescription scanning, schedule duration tracking, background audible alarms, and doctor appointment management.

---

## 🌟 Key Highlights & Hackathon Features

| Feature | Description |
| :--- | :--- |
| **🔍 AI & OCR Prescription Scanner** | Upload any mobile photo, prescription slip, or doctor notes. Employs OCR & regex entity extraction to parse drug names (*Azithromycin, Paracetamol, Pantoprazole*), dosages, frequencies, and days duration. |
| **⏰ Background Web Audio Alarms** | Autonomous clock engine continuously checks scheduled dosage times and doctor appointments, triggering high-clarity dual-tone audible chime alarms directly in your browser. |
| **👨‍⚕️ Doctor Appointments with Reg No** | Book visits with Doctor Name, Medical Registration Number (e.g. *Dr. Ravikishan, MCI-48291*), Department (*Cardiology*), and automatic time-synchronized alarms (e.g. 2:30 PM). |
| **📅 Precise Dosing & Duration** | Schedule multiple taking times per day (*08:00 AM, 02:00 PM, 08:00 PM*) and exact course duration (*3, 5, 7, 10, 14, 30 days*). |
| **📦 Smart Inventory Auto-Deductions** | Deducts stock quantities upon dose confirmation and triggers alerts when supply drops below safety thresholds. |
| **🔒 Secure Credentials & Vault** | Persistent user authentication with strict password validation. Your health vault is locked and isolated in private browser storage. |

---

## 🚀 Live Demo & Quick Test Credentials

MediMate runs instantly in any modern web browser without server dependencies.

- **Demo Account:**
  - **Email:** `alex@meditrack.health`
  - **Password:** `password123`
- *(You can also click **Create Account** to register your own custom email and password!)*

---

## 📂 Project Repository Structure

```text
medimate/
├── index.html          # Full standalone single-page application (All views, state, and audio)
├── README.md           # Documentation, architecture, and deployment guide
├── LICENSE             # Open-source MIT license
├── package.json        # Node.js dev server configuration (optional)
└── .gitignore          # Git ignore rules
```

---

## 💻 Local Setup & Development

### Method 1: Instant Browser Launch (No tools required)
Simply double-click `index.html` or open it in any web browser (Chrome, Edge, Safari, Firefox).

### Method 2: Local HTTP Server (Recommended)
Using Python:
```bash
# Python 3
python3 -m http.server 3000
```
Then visit `http://localhost:3000` in your browser.

Using Node.js / npx:
```bash
npx serve .
```

---

## 🌐 1-Click Deployment Guide

### Deploy to GitHub Pages (Free & Instant)
1. Create a new repository on GitHub named `medimate` (or `medimate-health`).
2. Push this project to your repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: MediMate AI Health Platform"
   git branch -M main
   git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/medimate.git
   git push -u origin main
   ```
3. In your GitHub repository, go to **Settings** ➔ **Pages**.
4. Under **Source**, choose `Deploy from a branch` ➔ Branch: `main` ➔ `/ (root)` ➔ Click **Save**.
5. Your live site will be ready at: `https://<YOUR_GITHUB_USERNAME>.github.io/medimate/` 🎉

### Deploy to Vercel
1. Import your GitHub repo into [Vercel](https://vercel.com).
2. Framework Preset: **Other** (Root directory: `./`).
3. Click **Deploy**. Vercel will host it automatically with zero configuration.

### Deploy to Netlify
- Drag and drop this folder directly into [Netlify Drop](https://app.netlify.com/drop).

---

## 🏗️ Technical Architecture

- **Frontend & UI:** HTML5, CSS3, Tailwind CSS (Utility-first responsive design, Plus Jakarta Sans typography).
- **Audio Engine:** Native HTML5 Web Audio API synthesizer for zero-dependency audible alarm chimes.
- **Computer Vision & OCR:** Tesseract.js v5 with client-side canvas pre-processing.
- **NLP Extraction:** Regular expression entity parser for medications, dosages (mg/g/ml), frequencies (QD/BID/TID), and course durations.
- **Analytics & Data Visualizations:** Chart.js 4.4 for 7-day adherence reports.
- **State Management & Storage:** Reactive in-memory state engine synchronized with persistent `localStorage`.

---

## ⚠️ Medical Responsibility Notice

MediMate is designed as a personal reminder, schedule tracking, and health organization assistant. It is **not** a licensed medical diagnostic device and does not modify medical treatments. Always verify medications, dosages, and schedules with your qualified physician or pharmacist.

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
